int main (int argc, char *argv []) {
    int N = atoi (argv[1]);
    pthread_t *thread = malloc (N * sizeof (pthread_t));
    for (int i = 0; i < N; i++) {
        struct thread_arg arg;
        arg.value1 = i;
        arg.value2 = 'f';
        arg.value3 = i / 10.0;
        struct thread_arg *p = malloc (sizeof *p);
        *p = arg;
        pthread_create (& thread [i], NULL, foo, p);
    }
    free (thread);
    pthread_exit (NULL);
}



 

int main (int argc, char *argv[]) {
    int N = strtol(argv[1], NULL, 10);
    pthread_t *thread = (pthread_t *) malloc (N * sizeof(pthread_t));
    for (int i = 0; i < N; ++i) {
        struct thread_arg arg;
        arg.value1 = i * 5;
        arg.value2 = 'M';
        arg.value3 = i / 1.5;
        pthread_create(&thread[i], NULL, foo, &arg);
    }
    free(thread);
    pthread_exit(NULL);
}


