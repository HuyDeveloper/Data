int main (int argc, char *argv []) {
    struct termios orig_attr, new_attr;
    int c = '\0';
    int n = 5;
    tcgetattr (fileno (stdin), & orig_attr);
    memcpy (& new_attr, & orig_attr, sizeof (new_attr));
    new_attr.c_lflag &= ~(ICANON | ECHO);
    new_attr.c_cc[VMIN] = 0;
    new_attr.c_cc[VTIME] = 10;
    tcsetattr (fileno (stdin), TCSANOW, & new_attr);
    printf ("Starting with n = %d\n", n);
    do {
        c = getchar ();
        if (c != EOF) {
            n++;
            printf ("Key pressed!\n");
            printf ("n++ => %d\n", n);
        }
        else {
            n--;
            printf ("n-- => %d\n", n);
            if (n == 0) {
                printf ("Exiting ...\n");
                break;
            }
            if (feof (stdin)) {
                clearerr (stdin);
            }
        }
    }
    while (c != 'q');
    tcsetattr (fileno (stdin), TCSANOW, & orig_attr);
    return 0;
}





#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[]) {
    struct termios orig_attr, new_attr;
    int c;
    int n;

    tcgetattr(fileno(stdin), &orig_attr);
    new_attr = orig_attr;
    new_attr.c_lflag &=~ (ICANON | ECHO);
    new_attr.c_cc[VMIN] = 0;
    new_attr.c_cc[VTIME] = 5;
    tcsetattr(fileno(stdin), TCSANOW, &new_attr);

    for (n = 5; n != 0;) {
        c = fgetc(stdin);
        if (c == EOF) {
            clearerr(stdin);
            n--;
        } else if (c != 'q') {
            n++;
        } else {
            break;
        }
    }

    tcsetattr(fileno(stdin), TCSANOW, &orig_attr);
    return 0;
}


