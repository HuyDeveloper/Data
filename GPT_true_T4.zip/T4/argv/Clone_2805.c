int main (int argc, char *argv []) {
    struct termios orig_attr, new_attr;
    int c = '\0';
    int n = 5;
    tcgetattr (fileno (stdin), & orig_attr);
    memcpy (& new_attr, & orig_attr, sizeof (new_attr));
    new_attr.c_lflag &= ~(ICANON | ECHO);
    new_attr.c_cc[VMIN] = 0;
    new_attr.c_cc[VTIME] = 10;
    tcsetattr (fileno (stdin), TCSANOW, & new_attr);
    printf ("Starting with n = %d\n", n);
    do {
        c = getchar ();
        if (c != EOF) {
            n++;
            printf ("Key pressed!\n");
            printf ("n++ => %d\n", n);
        }
        else {
            n--;
            printf ("n-- => %d\n", n);
            if (n == 0) {
                printf ("Exiting ...\n");
                break;
            }
            if (feof (stdin)) {
                clearerr (stdin);
            }
        }
    }
    while (c != 'q');
    tcsetattr (fileno (stdin), TCSANOW, & orig_attr);
    return 0;
}





#include <stdlib.h>
#include <stdio.h>
#include <termios.h>
#include <string.h>

int main (int argc, char *argv []) {
    struct termios orig_attr, new_attr;
    int c = EOF;
    int n = 7;
    tcgetattr (0, & orig_attr);
    memcpy (& new_attr, & orig_attr, sizeof (new_attr));
    new_attr.c_lflag &= ~(ICANON | ECHO);
    new_attr.c_cc[VMIN] = 0;
    new_attr.c_cc[VTIME] = 100;
    tcsetattr (0, TCSANOW, & new_attr);
// Rest of the code
}


