int main (int argc, char *argv []) {
    char *file1, *file2, *file3;
    long num = 0;
    if (argc > 1) {
        file1 = malloc (strlen (argv[1]) + 1);
        strcpy (file1, argv [1]);
    }
    if (argc > 2) {
        file2 = malloc (strlen (argv[2]) + 1);
        strcpy (file2, argv [2]);
    }
    if (argc > 3) {
        file3 = malloc (strlen (argv[3]) + 1);
        strcpy (file3, argv [3]);
    }
    if (argc > 4) {num = strtol (argv [4], NULL, 0);}
}


 int main(int argc, char* argv[]) {
    char* file1, *file2, *file3;
    long num = 0;

    if (argc > 1) {
        size_t length1 = strlen(argv[1]);
        file1 = calloc(length1+1, sizeof(char));
        memcpy(file1, argv[1], length1);
    }

    if (argc > 2) {
        size_t length2 = strlen(argv[2]);
        file2 = calloc(length2+1, sizeof(char));
        memcpy(file2, argv[2], length2);
    }

    if (argc > 3) {
        size_t length3 = strlen(argv[3]);
        file3 = calloc(length3+1, sizeof(char));
        memcpy(file3, argv[3], length3);
    }

    if (argc > 4) {
        char *endptr;
        num = strtol(argv[4], &endptr, 0);
    }
}


