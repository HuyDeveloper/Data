int main (void) {
    int a [100];
    int n, x;
    int i = 0;
    scanf ("%d%d", & n, & x);
    for (i = 0; i < n; i++) {
        scanf ("%d", & a [i]);
    }
    return 0;
}


	int main (void) 
{
    int a [100];
    int m, x;
    int i = 0;
    printf("Enter array size : ");
    scanf ("%d", & m);
    printf("Enter %d elements of array : ",m);
    scanf ("%d", & x);
    for (i = 0; i < m; i++) {
        scanf ("%d", & a [i]);
    }
    return 0;
}


