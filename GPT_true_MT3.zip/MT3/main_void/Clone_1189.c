int main (void) {
    int n;
    GetSystemTimesAddress ();
    for (n = 0; n < 20; n++) {
        printf ("CPU Usage: %3d%%\r", cpuusage ());
        Sleep (2000);
    }
    printf ("\n");
    return 0;
}


  int main (void) {
    int n=0;
    GetSystemTimesAddress ();
    do
    {
        printf ("CPU Usage: %3d%%\r", cpuusage ());
        Sleep (2000);
        n++;
    }
    while (n < 20);
    printf ("\n");
    return 0;
}


