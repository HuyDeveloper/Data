int main (void) {
    int i;
    int arr [] = {1, 2, 3, 4, 5};
    slide_arr (arr, _countof (arr), 2);
    for (i = 0; i < _countof (arr); i++) {
        printf ("%d, ", arr [i]);
    }
    return EXIT_SUCCESS;
}



int main (void) {
    int i;
    int arr [] = {1, 2, 3, 4, 5};
    int size;
    size = sizeof(arr)/sizeof(arr[0]);
    slide_arr (arr, size, 2);
    for (i = 0; i < size; i++) {
        printf ("%d, ", arr[i]);
    }
    return EXIT_SUCCESS;
}


