int main (void) {
    int a [100];
    int n, x;
    int i = 0;
    scanf ("%d%d", & n, & x);
    for (i = 0; i < n; i++) {
        scanf ("%d", & a [i]);
    }
    return 0;
}


 int main (void) {
    int arrayqwert [100];
    int nlength, xitem;
    int sequentialNum = 0;
    printf("Please indicate size of an array : ");
    scanf ("%d", & nlength);
    printf("Please enter %d elements to fill the array : ",nlength);
    scanf ("%d", & xitem);
    for (sequentialNum = 0; sequentialNum < nlength; sequentialNum++) {
        scanf ("%d", & arrayqwert [sequentialNum]);
    }
    return 0;
}


