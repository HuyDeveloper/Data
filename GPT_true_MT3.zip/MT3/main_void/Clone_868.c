int main (void) {
    char str [] = "aaaaaaaa";
    size_t len_str = strlen (str);
    string *p = malloc (sizeof *p + len_str + 1);
    if (!p) {
        return 1;
    }
    p->size = len_str;
    strcpy (p -> str, str);
    puts (p -> str);
    strncpy (p -> str, str, len_str + 1);
    puts (p -> str);
    memcpy (p -> str, str, len_str + 1);
    puts (p -> str);
    free (p);
}


 
int main (void) {
    char str [] = "aaaaaaaa";
    size_t len_str = strlen (str);
    string *p = (string *)malloc (sizeof (string) + len_str + 1);
    if (!p) {
        return 1;
    }
    p->size = len_str;
    copy_s (p->str, len_str, str);
    printf ("%s\n", p->str);
    copy_s (p->str, len_str + 1, str, len_str);
    printf ("%s\n", p->str);
    copy_s (p->str, len_str + 1, str, len_str + 1);
    printf ("%s\n", p->str);
    free (p);
}


