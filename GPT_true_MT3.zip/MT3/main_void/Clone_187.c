int main (void) {
    int a [100];
    int n, x;
    int i = 0;
    scanf ("%d%d", & n, & x);
    for (i = 0; i < n; i++) {
        scanf ("%d", & a [i]);
    }
    return 0;
}


 int main (void) {
    int arrayData [100];
    int $_n, $x;
    int num = 0;
    printf("Please define length of the array : ");
    scanf ("%d", & $_n);
    printf("Enter %d elements of array : ",$_n);
    scanf ("%d", & $x);
    for (num = 0; num < $_n; num++) {
        scanf ("%d", & arrayData [num]);
    }
    return 0;
}


