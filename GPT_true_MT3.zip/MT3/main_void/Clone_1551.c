int main (void) {
    int n;
    scanf ("%d", & n);
    a = (int **) malloc (n * sizeof (int *));
    for (int i = 0; i < 5; i++) {
        a[i] = (int *) malloc (n * sizeof (int));
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf ("%d", & a [i] [j]);
        }
    }
    fun (n);
    return 0;
}


 int main (void) {
    int n;
    scanf ("%d", & n);
    long int ** a = (long int **) malloc (n * sizeof (long int *));
    for (int i = 0; i < n; i++) {
        a[i] = (long int *) calloc (n, sizeof (long int));
    }
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            a[i][j] = 0;
            scanf ("%li", & a [i] [j]);
        }
    }
    int res = fun (n);
    return 0;
}


