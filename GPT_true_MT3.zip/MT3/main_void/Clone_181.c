int main (void) {
    int a [100];
    int n, x;
    int i = 0;
    scanf ("%d%d", & n, & x);
    for (i = 0; i < n; i++) {
        scanf ("%d", & a [i]);
    }
    return 0;
}


 int main (void) {
    int arrayName [100];
    int sizeOfArray, num;
    int i = 0;
    printf("What is the length of the array : ");
    scanf ("%d", & sizeOfArray);
    printf("Enter %d elements of the array : ",sizeOfArray);
    scanf ("%d", & num);
    for (i = 0; i < sizeOfArray; i++) {
        scanf ("%d", & arrayName [i]);
    }
    return 0;
}


