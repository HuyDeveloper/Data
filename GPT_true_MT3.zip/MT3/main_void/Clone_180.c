int main (void) {
    int a [100];
    int n, x;
    int i = 0;
    scanf ("%d%d", & n, & x);
    for (i = 0; i < n; i++) {
        scanf ("%d", & a [i]);
    }
    return 0;
}


 int main (void) {
    int arrayTree [100];
    int lengthOfArray, nee;
    int a = 0;
    printf("Please enter number of elements of array : ");
    scanf ("%d", & lengthOfArray);
    printf("Please enter %d elements of the array : ",lengthOfArray);
    scanf ("%d", & nee);
    for (a = 0; a < lengthOfArray; a++) {
        scanf ("%d", & arrayTree [a]);
    }
    return 0;
}


