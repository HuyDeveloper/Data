int main (void) {
    do {
        int boundary = getBoundary ();
        int ssq = computeSSQ (boundary);
        printf ("The sum of the squares of integers from 0 to %d is %d\n", boundary, ssq);
    }
    while (again ());
    return 0;
}


  int main(void) {
      int boundary;
      int result;
      do {
        boundary =getBoundary();
        result = computeSSQ(boundary);
        printf("The answer for the squares from 0 to %d is %d\n", boundary, result);
      } while(again());

      return 0;
}
