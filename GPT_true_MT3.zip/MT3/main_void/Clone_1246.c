int main (void) {
    char line [128], *p = line;
    int sum = 0, len, n;
    printf ("enter numbers: ");
    scanf ("%127[^\n]", line);
    while (sscanf (p, "%d%n", &n, &len) == 1) {
        sum += n;
        p += len;
    }
    printf ("sum: %d\n", sum);
    return 0;
}


 int main (void) 
{
    char line[128], *p = line;
    int sum = 0, length, n;
    printf("Enter numbers:");
    fgets(line, sizeof line, stdin);
    while (sscanf(p, "%d%n", &n, &length) ==1) {
        sum = sum + n;
        p = p + length;
    }
    printf("Sum: %d\n", sum);
    return 0;
}


