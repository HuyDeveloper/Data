import re
import os

# Định nghĩa biểu thức chính quy để tìm kiếm các hàm C
function_regex = r"(\w+)\s*\([^)]*\)\s*\{?"

# Định nghĩa hàm để kiểm tra tệp
def check_file(file_path):
    with open(file_path, 'r') as file:
        content = file.read()

    # Tìm kiếm các hàm C trong nội dung tệp
    functions = re.findall(function_regex, content)

    # Kiểm tra xem mỗi hàm có lỗi cú pháp hay không
    for func in functions:
        func_pattern = r"\b" + func + r"\s*\([^)]*\)\s*\{?"
        if not re.search(func_pattern, content):
            print(f"Possible syntax error in function '{func}' in file '{file_path}'")

# Thư mục chứa các tệp cần kiểm tra
directory_path = './sal'

# Duyệt qua tất cả các tệp trong thư mục
for root, dirs, files in os.walk(directory_path):
    for file in files:
        file_path = os.path.join(root, file)
        check_file(file_path)
