#!/bin/bash

# Thư mục nguồn
SOURCE_DIR="./sal"

# Thư mục đích
DEST_DIR="./NotHaveInputParameters"

# Biểu thức chính quy để tìm kiếm hàm C không có tham số
FUNCTION_REGEX="^[a-zA-Z_][a-zA-Z_0-9]*\s*\(\s*\)\s*\{"

# Tạo thư mục đích nếu chưa tồn tại
mkdir -p "$DEST_DIR"

# Duyệt qua tất cả các tệp trong thư mục nguồn
while IFS= read -r -d $'\0' file; do
    # Kiểm tra xem tệp có chứa hàm C không có tham số hay không
    if grep -qE "$FUNCTION_REGEX" "$file"; then
        # Di chuyển tệp sang thư mục đích
        mv "$file" "$DEST_DIR"
    fi
done < <(find "$SOURCE_DIR" -type f -print0)
