int main () {
    const int sum = 1000;
    int a;
    for (a = 1; a <= sum / 3; a++) {
        int b;
        for (b = a + 1; b <= sum / 2; b++) {
            int c = sum - a - b;
            if (a * a + b * b == c * c)
                printf ("a=%d, b=%d, c=%d\n", a, b, c);
        }
    }
    return 0;
}



 

#include <stdio.h>
void PythagoreanTriplets(int limit)
{
    int a;
    for (a = 1; a <= limit / 3; a++) {
        int b;
        for (b = a + 1; b <= limit / 2; b++) {
            int c = limit - a - b;
            if (a * a + b * b == c * c)
                printf ("a=%d, b=%d, c=%d\n", a, b, c);
        }
    }
    }
int main () {
    PythagoreanTriplets(1000); 
    return 0;
}


