int main () {
    char str1 [100] = "The quick brown fox jumps over ";
    char str2 [100] = "my big sphinx of quartz";
    int i = 0;
    int j = 0;
    while (str1[i] != '\0') {
        if (str1[i] != ' ')
            str1[j++] = str1[i];
        i++;
    }
    i = 0;
    while (str2[i] != '\0') {
        if (str2[i] != ' ' && j + 1 < sizeof (str1))
            str1[j++] = str2[i];
        i++;
    }
    str1[j] = '\0';
    printf ("'%s'\n", str1);
    return 0;
}



 

#include <stdio.h>
#include <string.h>
int main () {
    char str1[] = "The quick brown fox jumps over ";
    char str2[] = "my big sphinx of quartz";    
    for (int i = 0, j = 0; str1[i] != '\0'; str1[j] = str1[i], i++, j++)
        if (str1[i] == ' ') j--;
    for (int i = 0, j = strlen(str1); str2[i] != '\0'; str1[j] = str2[i], i++, j++)
        if (str2[i] == ' ') j--;
    printf("%s\n", str1);
    return 0;
}


