int main (void) {
    int oldar [2] [3] = {{1, 2, 3}, {4, 5, 6}};
    int newar [3] [2];
    transpose (& oldar [0] [0], & newar [0] [0], 2, 3);
    int i, j;
    for (i = 0; i < 2; i++) {
        for (j = 0; j < 3; j++)
            printf ("%d ", oldar[i][j]);
        printf ("\n");
    }
    for (i = 0; i < 3; i++) {
        for (j = 0; j < 2; j++)
            printf ("%d ", newar[i][j]);
        printf ("\n");
    }
}





void transpose(int* src, int* dst, int r, int c) {
    for(int i=0; i<r; i++)
        for(int j=0; j<c; j++)
            *(dst + j*r + i) = *(src + i*c + j);
}


