int main (void) {
    char str [] = "This is abc test abc string";
    char *in = str;
    char *delim = "abc";
    char *token;
    do {
        token = strstr (in, delim);
        if (token)
            *token = '\0';
        printf ("%s\n", in);
        in = token + strlen (delim);
    }
    while (token != NULL);
    return 0;
}




#include <string.h>
#include <stdio.h>

int main() {
    char str[] = "This is abc test abc string";
    char *sep = "abc";
    char *word = strtok(str, sep);
    while(word) {
        printf("%s\n", word);
        word = strtok(NULL, sep);
    }
    return 0;
}


