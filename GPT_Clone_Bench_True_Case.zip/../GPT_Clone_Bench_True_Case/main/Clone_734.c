int main () {
    char a [100] = "";
    char b [100] = "";
    fgets (a, 100, stdin);
    fgets (b, 100, stdin);
    size_t n = strlen (a);
    if (n && a[n - 1] == '\n')
        a[--n] = 0;
    n = strlen (b);
    if (n && b[n - 1] == '\n')
        b[--n] = 0;
    printf ("%s\n%s", a, b);
}


 int main() {
    char a[100], b[100];
    fgets(a, 100, stdin);
    fgets(b, 100, stdin);
    if (strcmp(&a[strlen(a) - 1], "\n") == 0)
        a[strlen(a) - 1] = '\0';
    if (strcmp(&b[strlen(b) - 1], "\n") == 0)
        b[strlen(b) - 1] = '\0';
    printf("%s\n%s", a, b);
}


