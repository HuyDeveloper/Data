main () {
    int c;
    while (1) {
        c = getchar ();
        if (c == EOF) {
            break;
        }
        putchar (c);
    }
}


 main () {
 for (int c = getchar(); c != EOF; c = getchar()) {
        putchar(c);
    }
}


